using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;

namespace Test.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StoreController : ControllerBase
    {
        public const string CountryCodeHeaderName = "x-test-country-code";

        private readonly IRepository _repository;

        public StoreController(
            IRepository repository
        )
        {
            _repository = repository;
        }

        // Return UnauthorizedResult() or OkObjectResult(ICollection<Store>)
        [HttpGet("StoreList")]
        public IActionResult GetStores()
        {
            string countryCode = ValidateCountryCodeHeader(Request, CountryCodeHeaderName);

            if(string.IsNullOrWhiteSpace(countryCode))
                return new UnauthorizedResult();

            var res = _repository.GetStores((Store x) => x.CountryCode == countryCode, false);
            return Ok(res);
        }

        // Return UnauthorizedResult(), NotFoundResult(), ForbidResult() or OkObjectResult(Store)
        public IActionResult GetStore(int storeId, bool includeCustomers = false)
        {
            string countryCode = ValidateCountryCodeHeader(Request, CountryCodeHeaderName);

            if(string.IsNullOrWhiteSpace(countryCode))
                return new UnauthorizedResult();
                
            var res = _repository.GetStores((Store x) => x.CountryCode == countryCode, includeCustomers);

            if(res == null || !res.Any())
                return new ForbidResult();

            var filteredResult = res.Where(s=> s.StoreId == storeId).ToList();
            if(!filteredResult.Any())
                return new NotFoundResult();

            return Ok(filteredResult);
        }

        // Return UnauthorizedResult(), BadRequestResult() or OkObjectResult(Customer)
        [HttpPost]
        public IActionResult CreateCustomer(Customer customer)
        {
            string countryCode = ValidateCountryCodeHeader(Request, CountryCodeHeaderName);

            if(string.IsNullOrWhiteSpace(countryCode))
                return new UnauthorizedResult();

            if(!ModelState.IsValid)
                return BadRequest("invalid data");

            return Ok();
        }

        private string ValidateCountryCodeHeader(HttpRequest request, string headerKey){
            int headerCount = 0;
            request.Headers.TryGetValue(headerKey, out var header);
            headerCount = header.Count;

            if(headerCount == 0 || headerCount > 1 || string.IsNullOrWhiteSpace(header))
                return null;

            return header;
        }
    }
}