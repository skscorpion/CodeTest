using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;

namespace Test.Controllers
{
    [ApiController]
    [Route("api/articles")]
    public class ArticleController : ControllerBase
    {

        private readonly IRepository _repository;

        public ArticleController(
            IRepository repository
        )
        {
            _repository = repository;
        }

        [HttpGet("{id}")]
        public IActionResult Get(Guid id)
        {
            var res = _repository.Get(id);

            if(res == null)
                return NotFound("Article not found");

            return Ok(res);
        }

        [HttpPost]
        public IActionResult Post(Article article)
        {
            if(article == null || string.IsNullOrWhiteSpace(article.Title))
                return BadRequest("Invalid request data");

            var articleId = _repository.Create(article);
            Console.WriteLine($"test: {articleId}");
            article.Id = articleId;
            return CreatedAtAction(nameof(Get), new { id = article.Id }, article);
        }

        [HttpPut("{id}")]
        public IActionResult Put(Guid id, [FromBody] Article article)
        {
            if(article == null || string.IsNullOrWhiteSpace(article.Title))
                return BadRequest("Invalid request data");

            var res = _repository.Update(article);

            if(!res)
                return NotFound("Article not found");

            return Ok();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            var res = _repository.Delete(id);

            if(!res)
                return NotFound("Article not found");

            return Ok();
        }
    }
}