using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;

namespace Test.Controllers
{
    public class Repository : IRepository
    {
        List<Store> stores = new List<Store>{
                new Store { StoreId = 1, CountryCode = "IN", Customers = new List<Customer>() },
                new Store { StoreId = 2, CountryCode = "FR", Customers = new List<Customer>() },
                new Store { StoreId = 3, CountryCode = "IN", Customers = new List<Customer>() },
                new Store { StoreId = 4, CountryCode = "SP", Customers = new List<Customer>() },
                new Store { StoreId = 5, CountryCode = "IN", Customers = new List<Customer>() }
            };

        List<Customer> customers = new List<Customer> {
            new Customer { CustomerId = 1, StoreId = 1, Email = "test@test.com" },
            new Customer { CustomerId = 2, StoreId = 3, Email = "test2@test.com" },
            new Customer { CustomerId = 3, StoreId = 4, Email = "test3@test.com" }
        };

        List<Article> articles = new List<Article> {
            new Article { Id = new Guid("148eb157-60c2-4783-90dc-8e7c0fe5b0a7"), Title = "Title 1", Text = "article 1" },
            new Article { Id = new Guid("6d56fc08-6f55-483e-ae89-1bc0c8d7fe12"), Title = "Title 2", Text = "article 2" },
            new Article { Id = new Guid("71daa26f-bf85-4ed1-8b74-aaf575dc5b6c"), Title = "Title 3", Text = "article 3" },
            new Article { Id = new Guid("91c9d6c3-d621-4f37-954e-a41672c37b9c"), Title = "Title 4", Text = "article 4" },
            new Article { Id = new Guid("d2087316-5316-44b7-8e9d-997c26897905"), Title = "Title 5", Text = "article 5" }
        };

        public Repository()
        {
        }

        Customer IRepository.AddCustomer(Customer customer)
        {
            throw new NotImplementedException();
        }

        ICollection<Customer> IRepository.GetCustomers(int storeId)
        {
            throw new NotImplementedException();
        }

        ICollection<Store> IRepository.GetStores(Func<Store, bool> filter, bool includeCustomers)
        {
            // var storeList = GetStoreList();
            
            return stores.Where(filter).ToList();
        }

        private ICollection<Store> GetStoreList(){
            var lst = new List<Store>{
                new Store { StoreId = 1, CountryCode = "IN", Customers = new List<Customer>() },
                new Store { StoreId = 2, CountryCode = "FR", Customers = new List<Customer>() },
                new Store { StoreId = 3, CountryCode = "IN", Customers = new List<Customer>() },
                new Store { StoreId = 4, CountryCode = "SP", Customers = new List<Customer>() },
                new Store { StoreId = 5, CountryCode = "IN", Customers = new List<Customer>() }
            };
            return lst;
        }

        Article IRepository.Get(Guid id)
        {
            var article = articles.Where(x => x.Id == id).FirstOrDefault();
            return article;
        }

        Guid IRepository.Create(Article article)
        {
            article.Id = Guid.NewGuid();
            articles.Add(article);

            return article.Id;
        }

        bool IRepository.Delete(Guid id)
        {
            var article = articles.Where(x => x.Id == id).FirstOrDefault();
            if(article == null)
                return false;

            articles.Remove(article);
            return true;
        }

        bool IRepository.Update(Article articleToUpdate)
        {
            var article = articles.Where(x => x.Id == articleToUpdate.Id).FirstOrDefault();
            if(article == null)
                return false;

            return true;
        }
    }
}